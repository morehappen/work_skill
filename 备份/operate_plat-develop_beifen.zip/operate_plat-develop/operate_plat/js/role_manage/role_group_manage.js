//点击添加
$('.addBtn').click(function(){
	var html = template('ajax_alert', {});
        $.popwin(html, {
            title: '您准备将员工分配到以下店铺，请确认该操作',
            fixed: true,
            drag: false, //是否可拖拽
        });
        $("#popwin_Out").addClass("attr_manag_add");
        $.popwin.setPosition(410,460);
})