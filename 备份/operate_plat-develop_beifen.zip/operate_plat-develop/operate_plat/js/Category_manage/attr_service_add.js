var _id = +$.getUrlParam("id");//本行数据id
var _edit = $.getUrlParam("edit");//本行数据id
var _goodtype = $.getUrlParam("goodtype");//本行数据id
var _send = $.getUrlParam("send");//本行数据id
var _measure = $.getUrlParam("measure");//本行数据id
debugger;
var _install = $.getUrlParam("install");//本行数据id
// var _self = $.getUrlParam("self");//本行数据id

$.sidebarMenu($('.sidebar-menu'));
//分页地址变量
var localUrl = getBaseUrl('w');
//添加服务属性地址
var service_addUrl = localUrl + '/goods/service/add';
//编辑服务属性地址
var service_editUrl = localUrl + '/goods/service/changeService';
//分类包含层级地址,新建时候用
var xinjian_category_threeUrl = localUrl + '/goods/GoodsClassification/findAllBackClassOpen';
//分类包含层级地址,编辑时候用
var bianji_category_threeUrl = localUrl + '/goods/GoodsClassification/findAllBackClass';
//根据id查询已经勾选的情况
var return_checkUrl = localUrl + '/goods/service/findLeafClassIdByServiceId';
//查询已经挂载过服务的后台叶子分类id集合
var addFilter_checkUrl = localUrl + '/goods/service/findServiceLeafClassIds';
//根据不同类型，拉取对应的集合
var checkboxType_pullUrl = localUrl + '/goods/serviceDetails/showDetailsByTypeNoUse';
//根据不同类型和id拉取对应的集合
var checkboxHas_pullUrl = localUrl + '/goods/serviceDetails/findById';
var regex_reName = /[\u4e00-\u9fa5_a-zA-Z0-9_]{1,10}/;
$(function () {
    nav_Common_fun("服务属性","添加类型");
    var nameflag = false;
    var leafClassIdFlag = false;
    var checkFlag = false;
    //渲染三级分类包含
    if (_edit == 1) {
        nav_Common_fun("服务属性","编辑类型");
        // edit_category_threePull(bianji_category_threeUrl);
        // category_checkPull(params,category_hascheckUrl);
        // $(".edit_filter_tip").show();
        // $(".close_filter_tip").show();
        $(".goodsType_input").val(_goodtype);
        // $(".send").val(_send);
        debugger;
        $(".messure").val(_measure);
        $(".install").val(_install);
        $(".messure").attr('disabled', 'disabled');
        $(".install").attr('disabled', 'disabled');
        debugger;
        _messure = $(".messure").val();
        _install = $(".install").val();
        if (_messure == 1) {
            var installParams = {
                type: 0
            };
            var installParamsHas = {
                type: 0,
                id: _id
            };
            var domFather = $(".measure_checbox_box");
            checkbox_pull(installParams, domFather);
            var domFatherHas = $(".measure_checbox");
            checkboxHas_pull(installParamsHas,domFatherHas);
        }
        if (_install == 1) {
            var installParams = {
                type: 1
            };
            var installParamsHas = {
                type: 1,
                id: _id
            };
            var domFather = $(".install_checbox_box");
            checkbox_pull(installParams, domFather);
            var domFatherHas = $(".install_checbox");
            checkboxHas_pull(installParamsHas,domFatherHas);
        }
        $(".messure").change(function () {
            var _type = $(this).val();
            if (_type == 1) {
                var installParams = {
                    type: 0
                }
                var domFather = $(".measure_checbox_box");
                checkbox_pull(installParams, domFather)
            }
        })
        $(".install").change(function () {
            var _type = $(this).val();
            if (_type == 1) {
                var installParams = {
                    type: 1
                }
                var domFather = $(".install_checbox_box");
                checkbox_pull(installParams, domFather)
            }
        });
        // $(".self").val(_self);
    } else if (_edit == 0) {
        // add_category_threePull(xinjian_category_threeUrl);
        $(".edit_filter_tip").hide();
        $(".close_filter_tip").hide();

        $.ajax({
            type: "post",
            catch: false,
            async: false,
            url: addFilter_checkUrl,
            dataType: "json",
            success: function (data) {

                var res = data.data;
                var useArr = [];
                if (data.success == true) {
                    useArr = data.data;
                    console.log(useArr);
                }
                $(".relation_tip3 input[type='checkbox']").each(function (jj, kk) {
                    $(useArr).each(function (ii, vv) {
                        if ($(kk).val() == vv) {

                            $(kk).prop('checked', false);
                            $(kk).parent().addClass("addFilter_color");
                            $(kk).attr("disabled", "disabled");
                        }
                    })
                })
                $('.add_filter_tip').html("红色为其他服务占用的叶子分类，不可勾选").show();
            },
            error: function () {
            }
        });
    }
    ;
    $(".messure").change(function () {
        var _type = $(this).val();
        if (_type == 1) {
            var installParams = {
                type: 0
            }
            var domFather = $(".measure_checbox_box")

            checkbox_pull(installParams, domFather)
        } else {
            $(".measure_checbox_box").html("");
        }
    })
    $(".install").change(function () {
        var _type = $(this).val();
        if (_type == 1) {
            var installParams = {
                type: 1
            }
            var domFather = $(".install_checbox_box");
            checkbox_pull(installParams, domFather)
        } else {
            $(".install_checbox_box").html("");
        }
    });
    var addDom = $(".attr_manag_con_right .sure_xsBtn");
    //属性名称输入失焦事件
    $(".goodsType_input").blur(function () {
        if (regex_reName.test($('.goodsType_input').val())) {
            $('.type_input_tip').hide();
            nameflag = true;
        } else {
            $('.type_input_tip').html('不可空置/支持中英文，最多10个字符').show();
            nameflag = false;
        }
    });
    //主按钮提交数据事件
    addDom.off('click').on('click', function () {
        debugger;
        var _leafClassId = "";
        var push_res_arr = [];
        var measureCheckDom = $(".measure_checbox_box input[type='checkbox']:checked");
        var installCheckDom = $(".install_checbox_box input[type='checkbox']:checked");
        measureCheckDom.each(function (i, v) {
            push_res_arr.push($(v).val())
        })
        installCheckDom.each(function (i, v) {
            push_res_arr.push($(v).val())
        })
        _leafClassId = push_res_arr.toString();
        // flag = regex_reName.test($('.type_input_tip').val());
        var _type = $.trim($(".goodsType_input").val());
        debugger//@属性名称
        var _send = 1;
        var _messure = +$(".messure").val();
        var _install = +$(".install").val();
        // var selfLiftingService = +$(".self").val();
        if (_messure == 0 && _install == 0) {
            _leafClassId = ""
        }
        param_btn_push = {
            goodsType: _type,//类型
            sendService: _send,//配送
            measureService: _messure,//测量
            installService: _install,//安装
            serviceDetailsIds: _leafClassId//叶子集合
            // selfLiftingService:selfLiftingService// selfLiftingService该字段被去掉
        };

        if (_edit == 1) {
            debugger;
            var _messureFlag = false;//测量服务旗帜
            var _installFlag = false;//安装服务旗帜
            var doubleFlag = false;//两旗合并
            if (_messure == 1) {
                if (measureCheckDom.length == 0) {
                    _messureFlag = false;
                    $('.messure_tip').html('没有勾选测量服务复选框').show();
                } else {
                    _messureFlag = true;
                    $('.messure_tip').hide();
                }
            } else {
                _messureFlag = true;
            }
            if (_install == 1) {
                if (installCheckDom.length == 0) {
                    _installFlag = false;
                    $('.install_tip').html('没有勾选安装服务复选框').show();
                } else {
                    _installFlag = true;
                    $('.install_tip').hide();
                }
            } else {
                _installFlag = true
            }
            if (_messureFlag && _installFlag) {
                doubleFlag = true;
            }
            service_addUrl = service_editUrl;
            param_btn_push = {
                id: _id,
                goodsType: _type,//类型
                sendService: _send,//配送
                measureService: _messure,//测量
                installService: _install,//安装
                serviceDetailsIds: _leafClassId//叶子集合
                // value:_value,//这个字段是干啥的
                // selfLiftingService:selfLiftingService// selfLiftingService该字段被去掉吗？
            };
            if (!nameflag && !_type) {
                debugger;
                nameflag = false;
                var html = template('test_mask_catch', {});
                $.popwin(html, {
                    title: '',
                    fixed: true,
                    drag: false, //是否可拖拽
                });
                $("#popwin_Out").addClass("attr_manag_add");
                $.popwin.setPosition(410, 460);
                $(".attr_manag_add .mask_tip").html("请填写商品类型");
                $('.type_input_tip').html('不可空置/支持中英文，最多10个字符').show();
                return false;
            } else {
                nameflag = true;
                $('.type_input_tip').hide();
            }
            if (nameflag && doubleFlag) {
                checkFlag = true;
            }
            if (checkFlag) {
                debugger;
                $.ajax({
                    url: service_addUrl,
                    type: 'post',
                    dataType: 'json',
                    data: param_btn_push,
                    success: function (data) {

                        if (data.success == true) {
                            var html = template('test_mask_catch', {});
                            $.popwin(html, {
                                title: '',
                                fixed: true,
                                drag: false, //是否可拖拽
                            });
                            $("#popwin_Out").addClass("attr_manag_add");
                            $.popwin.setPosition(410, 460);
                            $(".attr_manag_add .mask_tip").html(data.message);
                            $("#popwin_Close").on("click", function () {
                                self.location = document.referrer;
                            })
                        } else {
                            var html = template('test_mask_catch', {});
                            $.popwin(html, {
                                title: '',
                                fixed: true,
                                drag: false, //是否可拖拽
                            });
                            $("#popwin_Out").addClass("attr_manag_add");
                            $.popwin.setPosition(410, 460);
                            $(".attr_manag_add .mask_tip").html(data.message);
                            // alert(msg);
                        }
                    }
                });
            }
        } else {
            var _messureFlag = false;//测量服务旗帜
            var _installFlag = false;//安装服务旗帜
            var doubleFlag = false;//两旗合并
            if (_messure == 1) {
                if (measureCheckDom.length == 0) {
                    _messureFlag = false;
                    $('.messure_tip').html('没有勾选测量服务复选框').show();
                } else {
                    _messureFlag = true;
                    $('.messure_tip').hide();
                }
            } else {
                _messureFlag = true;
            }
            if (_install == 1) {
                if (installCheckDom.length == 0) {
                    _installFlag = false;
                    $('.install_tip').html('没有勾选安装服务复选框').show();
                } else {
                    _installFlag = true;
                    $('.install_tip').hide();
                }
            } else {
                _installFlag = true
            }
            if (_messureFlag && _installFlag) {
                doubleFlag = true;
            }
            // _leafClassId = JSON.stringify(_leafClassId);
            param_btn_push = {
                goodsType: _type,//类型
                sendService: _send,//配送
                measureService: _messure,//测量
                installService: _install,//安装
                serviceDetailsIds: _leafClassId//叶子集合
                // value:_value,//这个字段是干啥的
                // selfLiftingService:selfLiftingService
            };
            if (!nameflag || !_type) {
                nameflag = false;
                var html = template('test_mask_catch', {});
                $.popwin(html, {
                    title: '',
                    fixed: true,
                    drag: false, //是否可拖拽
                });
                $("#popwin_Out").addClass("attr_manag_add");
                $.popwin.setPosition(410, 460);
                $(".attr_manag_add .mask_tip").html("请填写商品类型");
                $('.type_input_tip').html('不可空置/支持中英文，最多10个字符').show();
                return false;
            } else {
                nameflag = true;
                $('.type_input_tip').html('不可空置/支持中英文，最多10个字符').hide();
            }
            // if (nameflag && _leafClassId.length > 0) {
            //     leafClassIdFlag = true;
            //     $('.relation_cate_tip ').hide();
            // }
            if (nameflag && doubleFlag) {
                checkFlag = true;
            }
            if (checkFlag) {
                $.ajax({
                    url: service_addUrl,
                    type: 'post',
                    dataType: 'json',
                    data: param_btn_push,
                    success: function (data) {

                        if (data.success == true) {
                            var html = template('test_mask_catch', {});
                            $.popwin(html, {
                                title: '',
                                fixed: true,
                                drag: false, //是否可拖拽
                            });
                            $("#popwin_Out").addClass("attr_manag_add");
                            $.popwin.setPosition(410, 460);
                            $(".attr_manag_add .mask_tip").html("添加成功");
                            $("#popwin_Close").on("click", function () {
                                self.location = document.referrer;
                            })
                        } else {
                            var html = template('test_mask_catch', {});
                            $.popwin(html, {
                                title: '',
                                fixed: true,
                                drag: false, //是否可拖拽
                            });
                            $("#popwin_Out").addClass("attr_manag_add");
                            $.popwin.setPosition(410, 460);
                            $(".attr_manag_add .mask_tip").html(data.message);
                            // alert(msg);
                        }
                    }
                });
            }
        }

    });
    $(".attr_manag_con_right .cancle_xsBtn").on('click', function () {
        window.history.back(-1);
    })

})

//新建时候，无传参拉取嵌套层级分类包含信息
function add_category_threePull(category_threeUrl) {
    var dataJson = {};
    $.ajax({
        type: "post",
        catch: false,
        async: false,
        url: category_threeUrl,
        dataType: "json",
        // data: params,
        success: function (res) {
            if (res.success == true) {
                var arr = [];//空数组
                var data = res.data;//提取数组
                for (var i = 0; i < data.length; i++) {
                    if (data[i].parentId == 0) {
                        var obj = {};//存储所有一级的键值对
                        obj.id = data[i].id;
                        obj.name = data[i].name;
                        var secondArr = [];
                        for (var j = 0; j < data.length; j++) {

                            if (data[j].parentId == obj.id) {
                                var obj2 = {};
                                obj2.id = data[j].id;
                                obj2.name = data[j].name;
                                //存储新对象进入每一个一级目录中
                                secondArr.push(obj2);
                                var thirdArr = [];
                                for (var k = 0; k < data.length; k++) {
                                    var obj3 = {};
                                    if (data[k].parentId == obj2.id) {
                                        obj3.id = data[k].id;
                                        obj3.name = data[k].name;
                                        thirdArr.push(obj3);
                                    }

                                }
                                obj2.child = thirdArr;
                            }

                            //遍历3级菜单；
                        }
                        obj.child = secondArr;
                        arr.push(obj);
                    }
                }
                ;
                dataJson.options = arr;
                var html = template("belong_box", dataJson);
                $('.relation_table').html(html);
            } else {

            }
        },
        error: function () {
        }
    });

}

//编辑时候，无传参拉取嵌套层级分类包含信息
function edit_category_threePull(category_threeUrl) {
    var dataJson = {};

    $.ajax({
        type: "post",
        catch: false,
        async: false,
        url: category_threeUrl,
        dataType: "json",
        // data: params,
        success: function (res) {
            if (res.success == true) {
                var arr = [];//空数组
                var data = res.data;//提取数组
                for (var i = 0; i < data.length; i++) {
                    if (data[i].parentId == 0) {
                        var obj = {};//存储所有一级的键值对
                        obj.id = data[i].id;
                        obj.name = data[i].name;
                        obj.state = data[i].state;
                        var secondArr = [];
                        for (var j = 0; j < data.length; j++) {

                            if (data[j].parentId == obj.id) {
                                var obj2 = {};
                                obj2.id = data[j].id;
                                obj2.name = data[j].name;
                                obj2.state = data[j].state;
                                //存储新对象进入每一个一级目录中
                                secondArr.push(obj2);
                                var thirdArr = [];
                                for (var k = 0; k < data.length; k++) {
                                    var obj3 = {};
                                    if (data[k].parentId == obj2.id) {
                                        obj3.id = data[k].id;
                                        obj3.name = data[k].name;
                                        obj3.state = data[k].state;
                                        thirdArr.push(obj3);
                                    }

                                }
                                obj2.child = thirdArr;
                            }

                            //遍历3级菜单；
                        }
                        obj.child = secondArr;
                        arr.push(obj);
                    }
                }
                ;
                dataJson.options = arr;
                var html = template("belong_box", dataJson);
                $('.relation_table').html(html);
                $(".relation_tip3 input[type='checkbox']").each(function (jjj, kkk) {
                    if ($(kkk).data("state") == 1) {

                        $(kkk).parent().addClass("closeFilter_color");
                        $(kkk).attr("disabled", "disabled");
                    }
                })
            } else {

            }
        },
        error: function () {
        }
    });

}

function category_checkPull(params, category_hascheckUrl) {
    // var dataJson = {};
    $.ajax({
        type: "post",
        catch: false,
        async: false,
        url: category_hascheckUrl,
        dataType: "json",
        data: params,
        success: function (res) {

            if (res.success == true) {
                var arr = [];//空数组
                var data = res.data;//提取数组
                for (var i = 0; i < data.length; i++) {
                    if (data[i].parentId == 0) {
                        var obj = {};//存储所有一级的键值对
                        obj.id = data[i].id;
                        obj.name = data[i].name;
                        var secondArr = [];
                        for (var j = 0; j < data.length; j++) {

                            if (data[j].parentId == obj.id) {
                                var obj2 = {};
                                obj2.id = data[j].id;
                                obj2.name = data[j].name;
                                //存储新对象进入每一个一级目录中
                                secondArr.push(obj2);
                                var thirdArr = [];
                                for (var k = 0; k < data.length; k++) {
                                    var obj3 = {};
                                    if (data[k].parentId == obj2.id) {
                                        obj3.id = data[k].id;
                                        obj3.name = data[k].name;
                                        thirdArr.push(obj3);
                                    }

                                }
                                obj2.child = thirdArr;
                            }

                            //遍历3级菜单；
                        }
                        obj.child = secondArr;
                        arr.push(obj);
                    }
                }
                ;
                dataJson.options = arr;

                var html = template("belong_box", dataJson);
                $('.relation_table').html(html);
            } else {

            }
        },
        error: function () {
        }
    });

}

//根据type拉取不同服务对应的复选框的交互函数
function checkbox_pull(params, domFather) {
    $.ajax({
        type: "post",
        catch: false,
        async: false,
        url: checkboxType_pullUrl,
        dataType: "json",
        data: params,
        success: function (res) {
            if (res.success == true) {
                debugger;
                var data = res.data;
                var str = "";
                $(data).each(function (i, v) {
                    if (params.type == 0) {
                        str += "<span><input class='measure_checbox' data-type='" + data[i].type + "' type='checkbox' value='" + data[i].id + "'>" + data[i].serviceDetailsName + "</span>"
                    } else {
                        str += "<span><input class='install_checbox' data-type='" + data[i].type + "' type='checkbox' value='" + data[i].id + "'>" + data[i].serviceDetailsName + "</span>"

                    }
                })
                domFather.html(str);
            }
        },
        error: function () {
        }
    });
}

//根据id拉取不同服务对应的已经选择的交互函数
function checkboxHas_pull(params,domFatherHas) {
    debugger;
    $.ajax({
        type: "post",
        catch: false,
        async: false,
        url: checkboxHas_pullUrl,
        dataType: "json",
        data: params,
        success: function (res) {
            debugger;
            if (res.success == true) {
                debugger;
                var data = res.data;
                var str = "";
                $(data).each(function (i, v) {
                    debugger;
                    domFatherHas.each(function (j, k) {
                        debugger;
                        if (v.id == $(k).val()) {
                            $(k).prop('checked', true);
                        }
                    })
                })
            }
        },
        error: function () {
        }
    });
}