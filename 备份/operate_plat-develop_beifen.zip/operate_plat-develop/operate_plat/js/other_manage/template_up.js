$(function () {
    CKEDITOR.replace('dianping-center', {visible:true});
})