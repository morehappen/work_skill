// var num = 0;
// $("#add").click(function(){
// 	num++;
//     var addURL = '<div class="mt"><input type="text" class="form-control" id="num'+num+'" >：<input type="text" placeholder="请输入渠道url地址" class="form-control url" name=""></div>'
	 
//     $('.addPT').append(addURL)
// })


var localHttp = 'http://172.16.40.157:8010';
var toAddUp = localHttp +'/messageserver/toAddUpgrade';

//更新渠道获取到 渠道和地址
var obj ={};
var arr =[];
var version;
var appType;
var forcee;
$('input[name="ios"]').click(function(){ 
	appType = $(this).val();
	obj.appType = appType;
	console.log(obj.appType)
})
//获取更新
$('input[name="update"]').click(function(){ 
	console.log($(this).val())
	obj.forcee = $(this).val();
	if (forcee ==1) {
		 $('.tipsred').show();
	}else{
		$('.tipsred').hide();
	}
})
//获取downloadChannel

function addBtn(){
	//获取版本号
	 obj.version = $('.version').val();
	//获取更新说明
	 obj.remarks = $('.remarks').val();
	// var mtLength =$('qd').find($('.mt'));
	$('.mt label').each(function(){
		// console.log($(this).text())
		var urlObj ={}; 
	  	 urlObj.downloadChannel = $(this).text();
	  	 urlObj.updateUrl = $(this).siblings('input').val();
	     arr.push(urlObj)

	  }) 
	    obj.arr = arr
		console.log(obj)
		// $.ajax({
 	// 		type:'post',
 	// 		dataType:'json',
 	// 		url:toAddUp,
 	// 		data:obj,
 	// 		success:function(data){
 	// 			console.log(data.message)
 	// 		},
 	// 		error:function(){
 	// 			console.log(34242)
 	// 		}

		// })
	

}
