import reimbursement from '../views/reimbursement/reimbursement'
import reimbook from '../views/reimbursement/reim-book'
export default [
    {
        path: '/Reimbursement',
        name: 'Reimbursement',
        component: reimbursement
    },
    {
        path: '/Reimbook',
        name: 'Reimbook',
        component: reimbook
    }
]