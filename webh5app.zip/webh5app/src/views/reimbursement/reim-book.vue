
<template>
    <div>
         <router-link to="/Reimbursement">测试跳转</router-link>
        测试页面专用
        <div @click="back()">
            返回首页
        </div>
    </div>
</template>


<script>
// import { Toast } from 'mint-ui';
export default {
    name:'Reimbook',
    data(){
        return {

        }
    },
    methods:{
        back(){
            window.location.href="/";
        }
    }
}
</script>