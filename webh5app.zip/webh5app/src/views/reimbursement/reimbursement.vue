
<template>
     <div>
         <router-link to="/Reimbook">测试跳转</router-link>
        测试跳转测试跳转测试跳转测试跳转测试跳转测试跳转测试跳转测试跳转测试跳转
    </div>
</template>


<script>
// import { Toast } from 'mint-ui';
export default {
    name:'Reimbursement',
    data(){
        return {

        }
    }
}
</script>